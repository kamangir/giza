from abcli.logger import get_logger
from gizai import ICON

logger = get_logger(ICON)
