NAME = "gizai"

ICON = "🔻"

DESCRIPTION = f"{ICON} A recipe for AI languages."

VERSION = "5.5.1"
