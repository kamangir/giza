NAME = "gizai"

ICON = "🔻"

DESCRIPTION = f"{ICON} A recipe for AI languages."

VERSION = "5.4.1"
